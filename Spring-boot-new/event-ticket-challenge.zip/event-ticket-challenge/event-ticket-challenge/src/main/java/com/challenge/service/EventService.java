package com.challenge.service;

import java.time.LocalDate;
import java.util.List;

import com.challenge.dto.EventInputDTO;
import com.challenge.dto.EventViewModelDTO;
import com.challenge.dto.TicketPurchaseInputDto;
import com.challenge.dto.TicketPurchaseViewDTO;

public interface EventService {
	
	public EventViewModelDTO createEvent(EventInputDTO requestDTO);
	
	public List<EventViewModelDTO> getAllEvents();
	
	public EventViewModelDTO getEventById(Long id);
	
	public List<EventViewModelDTO> getUpcomingEvents(LocalDate startDate , LocalDate endDate);
	
	public TicketPurchaseViewDTO purchaseEvent(TicketPurchaseInputDto requestDto);

	public void deleteEvent(Long id);
	
}
