package com.challenge.dto;

import java.math.BigDecimal;

public class TicketPurchaseViewDTO {
	private String message;
	private BigDecimal totalPrice;
	private int remainingTickets;
	
	public TicketPurchaseViewDTO(String message, BigDecimal totalPrice, int remainingTickets) {
		this.message = message;
		this.totalPrice = totalPrice;
		this.remainingTickets = remainingTickets;
	}

	public int getRemainingTickets() {
		return remainingTickets;
	}

	public void setRemainingTickets(int remainingTickets) {
		this.remainingTickets = remainingTickets;
	}

	public BigDecimal getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(BigDecimal totalPrice) {
		this.totalPrice = totalPrice;
	}

	public TicketPurchaseViewDTO() {
	}

	public TicketPurchaseViewDTO(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String m) {
		this.message = m;
	}

}
