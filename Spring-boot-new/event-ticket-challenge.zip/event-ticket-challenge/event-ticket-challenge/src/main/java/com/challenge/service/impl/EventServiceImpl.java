package com.challenge.service.impl;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.challenge.dto.EventInputDTO;
import com.challenge.dto.EventViewModelDTO;
import com.challenge.dto.TicketPurchaseInputDto;
import com.challenge.dto.TicketPurchaseViewDTO;
import com.challenge.entity.Event;
import com.challenge.exceptions.ResourceNotFoundException;
import com.challenge.exceptions.InsufficientTicketsException;
import com.challenge.mapper.EventMapper;
import com.challenge.repo.EventRepository;
import com.challenge.service.EventService;

@Service
public class EventServiceImpl implements EventService {

	@Autowired
	private EventRepository repository;

	@Autowired
	private EventMapper eventMapper;

	@Override
	public EventViewModelDTO createEvent(EventInputDTO inputDto) {
		Event event = eventMapper.toEventEntity(inputDto);
		Event toSave = repository.save(event);
		return eventMapper.toDto(toSave);
	}

	@Override
	public List<EventViewModelDTO> getAllEvents() {
		return repository.findAllByOrderByDateAscIdAsc()
			.stream()
			.map(e -> eventMapper.toDto(e))
			// .map(eventMapper::toDto)
			.toList();
	}

	@Override
	public EventViewModelDTO getEventById(Long id) {
		Event event = repository.findById(id)
			.orElseThrow(() -> new ResourceNotFoundException("Event not Found"));
		return eventMapper.toDto(event);
	}

	@Override
	public List<EventViewModelDTO> getUpcomingEvents(LocalDate startDate, LocalDate endDate) {
		// 4 possibilites
		// 1. Both null
		// 2. Start date null, end date is given
		// 3. End date null, start date is given
		// 4. Both given

		LocalDate today = LocalDate.now();
		LocalDate from = startDate == null ? today : startDate;
		LocalDate to = endDate == null ? LocalDate.MAX : endDate;

		// Return tickets between from and to (both dates inclusive)
		return repository.findAllByOrderByDateAscIdAsc()
			.stream()
			.filter(event -> {
				LocalDate d = event.getDate().toLocalDate();
				return !d.isBefore(from) && !d.isAfter(to);
			})
			.map(eventMapper::toDto)
			.toList();
	}

	@Override
	public TicketPurchaseViewDTO purchaseEvent(TicketPurchaseInputDto requestDto) {
		Event event = repository.findById(requestDto.getId())
			.orElseThrow(() -> new ResourceNotFoundException("Event not Found"));

		// Optional<Event> e = repository.findById(requestDto.getId());
		// if(e.isEmpty()) {
		// 	throw new ResourceNotFoundException("Event not Found");
		// }

		// Optional<String> xyz = Optional.empty();

		// Event e = repository.findById(requestDto.getId()).orElse(null);
		// if(e == null) {
		// 	throw new ResourceNotFoundException("Event not Found");
		// }
		
		if(requestDto.getQuantity() > event.getAvailableTickets()) {
			throw new InsufficientTicketsException("Tickets not available!");
		}

		int remainingTickets = event.getAvailableTickets() - requestDto.getQuantity();

		// Save remaining tickets in database
		event.setAvailableTickets(remainingTickets);
		repository.save(event);
		BigDecimal quantity = new BigDecimal(requestDto.getQuantity());
		BigDecimal totalPrice = event.getPrice().multiply(quantity);

		return new TicketPurchaseViewDTO("Purchase successfull", totalPrice, remainingTickets);
	}

	@Override
	public void deleteEvent(Long id) {
		Event event = repository.findById(id)
			.orElseThrow(() -> new ResourceNotFoundException("Event not Found"));
		repository.delete(event);
	}

}
