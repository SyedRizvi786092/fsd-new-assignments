package com.challenge.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.challenge.dto.EventDeletedViewModelDto;
import com.challenge.dto.EventInputDTO;
import com.challenge.dto.EventViewModelDTO;
import com.challenge.dto.TicketPurchaseInputDto;
import com.challenge.dto.TicketPurchaseViewDTO;
import com.challenge.exceptions.InvalidDateFormatException;
import com.challenge.exceptions.InvalidInputException;
import com.challenge.service.EventService;

@RestController
@RequestMapping("/api/events")
public class EventController {
	
	private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

	@Autowired
	private EventService eventService;

	// @Valid annotation was not written (important for passing multiple test cases)
	@PostMapping
	public ResponseEntity<EventViewModelDTO> createEvent(@Validated @RequestBody EventInputDTO requestDTO) {
		return ResponseEntity.status(HttpStatus.CREATED).body(eventService.createEvent(requestDTO));
	}

	@GetMapping("/{id}")
	public ResponseEntity<EventViewModelDTO> getEventById(@PathVariable Long id) {
		return ResponseEntity.ok(eventService.getEventById(id));
	}

	@GetMapping
	public ResponseEntity<List<EventViewModelDTO>> getAllEvents() {
		return ResponseEntity.ok(eventService.getAllEvents());
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<EventDeletedViewModelDto> deleteEvent(@PathVariable Long id) {
		eventService.deleteEvent(id);
		return ResponseEntity.ok(new EventDeletedViewModelDto("Event Deleted"));
	}

	// @Valid annotation was not written (important for passing multiple test cases)
	@PostMapping("/purchase")
	public ResponseEntity<TicketPurchaseViewDTO> purchaseEvent(@Validated @RequestBody TicketPurchaseInputDto requestDto)
	{
		return ResponseEntity.status(HttpStatus.CREATED).body(eventService.purchaseEvent(requestDto));
	}

	@GetMapping("/upcoming")
	public ResponseEntity<List<EventViewModelDTO>> getUpcomingEvents(
		@RequestParam(required = false) String startDate,
		@RequestParam(required = false) String endDate)
	{
		try {
			LocalDate sd = null;
			LocalDate ed = null;
			if (startDate != null) {
				sd = LocalDate.parse(startDate, formatter);
			}
			if (endDate != null) {
				ed = LocalDate.parse(endDate, formatter);
			}
			if (sd != null && ed != null) {
				if (sd.isAfter(ed)) {
					throw new InvalidInputException("Start Date cannot be after End Date");
				}
			}
			return ResponseEntity.ok(eventService.getUpcomingEvents(sd, ed));
		} catch (DateTimeParseException e) {
			throw new InvalidDateFormatException("Invalid date format. Use dd-MM-yyyy");
		}
	}
	
}
