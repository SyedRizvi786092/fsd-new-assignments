package com.challenge.mapper;

import java.time.LocalTime;

import org.springframework.stereotype.Component;

import com.challenge.dto.EventInputDTO;
import com.challenge.dto.EventViewModelDTO;
import com.challenge.entity.Event;

@Component
public class EventMapper {
	
	public Event toEventEntity(EventInputDTO dto) {
		Event event = new Event();
		
		event.setShowName(dto.getEventName());
		event.setAvailableTickets(dto.getAvailableTickets());
		event.setDate(dto.getDate().atTime(LocalTime.MIDNIGHT));
		event.setPrice(dto.getPrice());
		
		return event;
		
	}
	
	public EventViewModelDTO toDto(Event event) {
		EventViewModelDTO responseDTO = new EventViewModelDTO();

		responseDTO.setEventName(event.getShowName());
		responseDTO.setId(event.getId());
		responseDTO.setAvailableTickets(event.getAvailableTickets());
		responseDTO.setPrice(event.getPrice());
		responseDTO.setDate(event.getDate().toLocalDate());
		
		return responseDTO;
	}

}
