package com.example.dtoandcontroller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DtoandcontrollerApplicationTests {

	@Test
	void contextLoads() {
	}

}
