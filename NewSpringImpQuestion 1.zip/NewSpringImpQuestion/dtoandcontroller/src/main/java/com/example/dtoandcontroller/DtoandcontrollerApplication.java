package com.example.dtoandcontroller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DtoandcontrollerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DtoandcontrollerApplication.class, args);
	}

}
