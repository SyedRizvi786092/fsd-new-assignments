package com.hackerrank.gevents.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hackerrank.gevents.model.Event;
import com.hackerrank.gevents.repository.EventRepository;

@RestController
public class EventController {
	
	@Autowired
	EventRepository eventRepository;
	
	@PostMapping("/events")
	public ResponseEntity<Event> createEvent(@RequestBody Event event) {
		Event EVENT = eventRepository.save(event);
		return new ResponseEntity<Event>(EVENT, HttpStatus.CREATED);
	}
	
	@GetMapping("/events")
	public ResponseEntity<List<Event>> getAll() {
		List<Event> EVENT = eventRepository.findAll();
		return ResponseEntity.ok(EVENT);
	}	
	
	@GetMapping("/repos/{repoId}/events")
	public ResponseEntity<List<Event>> getByCollectionEvent(@PathVariable Integer repoId) {
		
		if(!eventRepository.existsByRepoId(repoId)) {
			
			return ResponseEntity.notFound().build();
		}
		
		List<Event> EVENT = eventRepository.findByRepoId(repoId);
		
		if(EVENT == null) {
			return ResponseEntity.notFound().build();
		}
		
			return ResponseEntity.ok(EVENT);
	}
	
	@GetMapping("/events/{eventId}")
	public ResponseEntity<Event> getByIdEvent(@PathVariable Integer eventId) {
		
		if(eventId == null || eventId < 0) {
			return ResponseEntity.notFound().build();
		}
		
		Event EVENT = eventRepository.findById(eventId).orElse(null);
		
		if(EVENT == null) {
			return ResponseEntity.notFound().build();
		}
		
		return ResponseEntity.ok(EVENT);
	}
		
}
