package com.hackerrank.restcontrolleradvice.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.hackerrank.restcontrolleradvice.dto.BuzzException;
import com.hackerrank.restcontrolleradvice.dto.FizzBuzzException;
import com.hackerrank.restcontrolleradvice.dto.FizzException;
import com.hackerrank.restcontrolleradvice.dto.GlobalError;

@RestControllerAdvice
public class FizzBuzzExceptionHandler extends ResponseEntityExceptionHandler {

  //TODO:: implement handler methods for FizzException, BuzzException and FizzBuzzException
	
	@ExceptionHandler(FizzException.class)
	public ResponseEntity<GlobalError> handleFizzException(FizzException e) {
		GlobalError globalError = new GlobalError(e.getMessage(), e.getErrorReason());
		return new ResponseEntity<GlobalError>(globalError, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(BuzzException.class)
	public ResponseEntity<GlobalError> handleBuzzException(BuzzException e) {
		GlobalError globalError = new GlobalError(e.getMessage(), e.getErrorReason());
		return new ResponseEntity<GlobalError>(globalError, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(FizzBuzzException.class)
	public ResponseEntity<GlobalError> handleFizzBuzzException(FizzBuzzException e) {
		GlobalError globalError = new GlobalError(e.getMessage(), e.getErrorReason());
//		return new ResponseEntity<GlobalError>(globalError, HttpStatus.INSUFFICIENT_STORAGE);
		return ResponseEntity.status(HttpStatus.INSUFFICIENT_STORAGE).body(globalError);
	}
}