package com.example.yml;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YmlApplicationTests {

	@Test
	void contextLoads() {
	}

}
