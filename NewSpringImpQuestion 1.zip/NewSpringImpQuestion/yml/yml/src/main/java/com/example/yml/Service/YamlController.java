package com.example.yml.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.coyote.Response;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.example.yml.Entity.User;

@RestController
public class YamlController {

    private final ReadYaml readYaml;

    YamlController(ReadYaml readYaml){
        this.readYaml = readYaml;
    }
    
    @GetMapping("/all")
    public List<String> getAll() {
        return readYaml.getList();
    }

    @GetMapping("/user")
    public List<User> getAllUser() {
        return readYaml.getUsers();
    }

    @GetMapping("/specificTopic/{index}")
    public User getTopicsById(@PathVariable int index){
        List<User> topics = readYaml.getUsers();
        if(index < 0 || index >= topics.size()){
            throw new IllegalArgumentException("Invalid Topics");
        }

        return topics.get(index);
    }

    @GetMapping("/count")
    public Integer countTopics() {
        return readYaml.getUsers().size();
    }

    @GetMapping("/existing/{name}")
    public Boolean UserDetailExistOrNot(@PathVariable String name) {
        List<User> users = new ArrayList<>(readYaml.getUsers());
        Iterator<User> itr = users.iterator();
        while(itr.hasNext()){
                User user = itr.next();
                if(user.getName().equalsIgnoreCase(name)){
                    return true;
                }
        }
        return false;
        // return users.contains(name);
    }

    @GetMapping("/{name}")
    public String NameExist(@PathVariable String name) {
        List<User> list = readYaml.getUsers();

        Iterator<User> itr = list.iterator();

        while(itr.hasNext()) {
            User user = itr.next();
            if(user.getName().equalsIgnoreCase(name))
            {
                return user.getName();
            }
        }

        return "Null, Empty";
    }

    @PostMapping("/CreatePost")
    public ResponseEntity<List<User>> create(@RequestBody User user) {
        List<User> list = readYaml.getUsers();

        if(list == null) {
            list = new ArrayList<>();
        }

        list.add(user);
        readYaml.setUsers(list);

        return ResponseEntity.ok(list);
    }

    @PutMapping("/putMapping/{id}")
    public ResponseEntity<List<User>> Update(@RequestBody User user, @PathVariable int id) {
        List<User> list = readYaml.getUsers();

        Iterator<User> itr = list.iterator();

        
        while (itr.hasNext()) {
            User u = itr.next();

            if (u.getId() == id) {

                u.setName(user.getName());
                u.setHealth(user.getHealth());

                readYaml.setUsers(list);
                return ResponseEntity.ok(list);
            }
        }


        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<List<User>> delete(@PathVariable int id) {
        List<User> list = readYaml.getUsers();

        Iterator<User> itr = list.iterator();

        while(itr.hasNext()) {
            User user = itr.next();

            if(user.getId() == id) {
                list.remove(id);
                readYaml.setUsers(list);
                return ResponseEntity.ok(list);
            }
        }

        return ResponseEntity.notFound().build();
    }
}