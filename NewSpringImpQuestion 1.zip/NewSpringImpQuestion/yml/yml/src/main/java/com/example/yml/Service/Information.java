package com.example.yml.Service;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.Name;
import org.springframework.stereotype.Component;

import com.example.yml.Entity.User;

import jakarta.annotation.PostConstruct;

@Component
@ConfigurationProperties( prefix = "app")
public class Information {
    
    @Name("info")
    List<String> CInformation;

    List<User> user;

    public List<String> getCInformation() {
        return CInformation;
    }

    public void setCInformation(List<String> CInformation) {
        this.CInformation = CInformation;
    }

    public List<User> getUser() {
        return user;
    }

    public void setUser(List<User> user) {
        this.user = user;
    }

    @PostConstruct
    public void init() {
        System.out.println(CInformation);
        System.out.println("User Details : " + user);

    }
}
