package com.example.yml.Service;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.bind.Name;
import org.springframework.stereotype.Component;

import com.example.yml.Entity.User;

import jakarta.annotation.PostConstruct;
import lombok.ToString;

@Component
@ConfigurationProperties("app")
public class ReadYaml {
 
    @Name("info")
    public List<String> list;
 
    @Name("user.details")
    public List<User> users;
 
    public List<User> getUsers() {
        return users;
    }

    public void setUsers(List<User> users) {
        this.users = users;
    }

    public List<String> getList() {
        return list;
    }
 
    public void setList(List<String> list) {
        this.list = list;
    }

 
    @PostConstruct
    public void init(){
        System.out.println("List Info" + list);
        System.out.println("Users: " + users);
        System.out.println("Users usimng get: " + getUsers());
    }   
}